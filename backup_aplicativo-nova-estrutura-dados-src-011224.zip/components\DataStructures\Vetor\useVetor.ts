// src/components/DataStructures/Vetor/useVetor.ts
import { useState, useCallback } from "react";

export interface VectorElement {
  value: number;
  id: string;
}

interface OperationHistory {
  operacao: string;
  timestamp: number;
  status: OperationState;
}

export enum OperationState {
  IDLE = 'idle',
  RUNNING = 'running',
  COMPLETED = 'completed',
  ERROR = 'error',
}

const validacoes = {
  validarNumero(valor: any): { valido: boolean; mensagem: string; valor?: number } {
    if (valor === undefined || valor === null || valor.trim() === '') {
      return { valido: false, mensagem: 'O valor não pode estar vazio' };
    }
    const numero = Number(valor);
    if (isNaN(numero)) {
      return { valido: false, mensagem: 'O valor deve ser um número' };
    }
    if (numero !== Math.floor(numero)) {
      return { valido: false, mensagem: 'O valor deve ser um número inteiro' };
    }
    if (numero < -1000 || numero > 1000) {
      return { valido: false, mensagem: 'O valor deve estar entre -1000 e 1000' };
    }
    return { valido: true, valor: numero, mensagem: 'Valor válido' };
  },
  validarIndice(indice: number, tamanhoAtual: number, capacidadeMaxima: number): { valido: boolean; mensagem: string } {
    if (!Number.isInteger(indice) || indice < 0) {
      return { valido: false, mensagem: 'Índice inválido' };
    }
    if (indice >= capacidadeMaxima) {
      return { valido: false, mensagem: `Índice maior que a capacidade máxima (${capacidadeMaxima -1})` };
    }
    if (indice > tamanhoAtual && ! (indice === tamanhoAtual && tamanhoAtual < capacidadeMaxima)) {
      return { valido: false, mensagem: `Índice com lacuna. Próximo índice válido: ${tamanhoAtual}` };
    }
    return { valido: true, mensagem: 'Índice válido' };
  }
};

export function useVetor(capacidadeInicial: number = 20) {
  const [elementos, setElementos] = useState<VectorElement[]>([]);
  const [historico, setHistorico] = useState<OperationHistory[]>([]);
  const [mensagemAcao, setMensagemAcao] = useState<string | null>(null);
  const [indiceDestacado, setIndiceDestacado] = useState<number | null>(null);
  const [operationState, setOperationState] = useState<OperationState>(OperationState.IDLE);

  const registrarOperacao = useCallback((operacao: string, status: OperationState = OperationState.COMPLETED) => {
    setHistorico(prev => [{ operacao, timestamp: Date.now(), status }, ...prev]);
    setMensagemAcao(operacao);
    setOperationState(status);
  }, []);

  const validarIndice = useCallback((indice: number, permiteIgualTamanho: boolean = false) => {
    const resultado = validacoes.validarIndice(
      indice,
      elementos.length,
      permiteIgualTamanho ? capacidadeInicial : capacidadeInicial - 1
    );
    if (!resultado.valido) {
      throw new Error(resultado.mensagem);
    }
  }, [elementos.length, capacidadeInicial]);

  const executarMetodo = useCallback(async (metodo: string, valor: string, indice: string, indiceSecundario?: string) => {
    try {
      setOperationState(OperationState.RUNNING);
      let resultado: any;
      switch (metodo) {
        case 'inserir': {
          const idx = parseInt(indice);
          const validacao = validacoes.validarNumero(valor);
          if (!validacao.valido) throw new Error(validacao.mensagem);
          const novoElemento = { value: validacao.valor!, id: Date.now().toString() };
          const novosElementos = [...elementos, novoElemento];
          novosElementos.splice(idx, 0, novoElemento);
          setElementos(novosElementos);
          setIndiceDestacado(idx);
          registrarOperacao(`Elemento ${validacao.valor} inserido na posição ${idx}`, OperationState.COMPLETED);
          resultado = novoElemento;
          break;
        }
        case 'remover': {
          const idx = parseInt(indice);
          validarIndice(idx);
          const novosElementos = [...elementos];
          const elementoRemovido = novosElementos.splice(idx, 1)[0];
          setElementos(novosElementos);
          registrarOperacao(`Elemento ${elementoRemovido.value} removido da posição ${idx}`, OperationState.COMPLETED);
          resultado = elementoRemovido;
          break;
        }
        case 'buscar': {
          const validacao = validacoes.validarNumero(valor);
          if (!validacao.valido) throw new Error(validacao.mensagem);
          const indiceEncontrado = elementos.findIndex(e => e.value === validacao.valor);
          registrarOperacao(`Elemento ${validacao.valor} ${indiceEncontrado !== -1 ? `encontrado na posição ${indiceEncontrado}` : 'não encontrado'}`, OperationState.COMPLETED);
          setIndiceDestacado(indiceEncontrado);
          resultado = indiceEncontrado;
          break;
        }
        case 'obterElemento': {
          const idx = parseInt(indice);
          validarIndice(idx);
          const elemento = elementos[idx];
          registrarOperacao(`Elemento na posição ${idx}: ${elemento.value}`, OperationState.COMPLETED);
          setIndiceDestacado(idx);
          resultado = elemento;
          break;
        }
        case 'definirElemento': {
          const idx = parseInt(indice);
          const validacao = validacoes.validarNumero(valor);
          if (!validacao.valido) throw new Error(validacao.mensagem);
          validarIndice(idx);
          const novosElementos = [...elementos];
          novosElementos[idx] = { value: validacao.valor!, id: Date.now().toString() };
          setElementos(novosElementos);
          setIndiceDestacado(idx);
          registrarOperacao(`Elemento na posição ${idx} atualizado para ${validacao.valor}`, OperationState.COMPLETED);
          resultado = { value: validacao.valor!, id: Date.now().toString() };
          break;
        }
        case 'tamanho': {
          registrarOperacao(`Tamanho do vetor: ${elementos.length}`, OperationState.COMPLETED);
          resultado = elementos.length;
          break;
        }
        case 'estaVazio': {
          const estaVazio = elementos.length === 0;
          registrarOperacao(`O vetor está ${estaVazio ? '' : 'não '}vazio`, OperationState.COMPLETED);
          resultado = estaVazio;
          break;
        }
        case 'limpar': {
          setElementos([]);
          registrarOperacao('Vetor limpo', OperationState.COMPLETED);
          resultado = null;
          break;
        }
        case 'ordenar': {
          const novosElementos = [...elementos].sort((a, b) => a.value - b.value);
          setElementos(novosElementos);
          registrarOperacao('Vetor ordenado', OperationState.COMPLETED);
          resultado = null;
          break;
        }
        case 'inverter': {
          const novosElementos = [...elementos].reverse();
          setElementos(novosElementos);
          registrarOperacao('Vetor invertido', OperationState.COMPLETED);
          resultado = null;
          break;
        }
        case 'adicionarNoFinal': {
          const validacao = validacoes.validarNumero(valor);
          if (!validacao.valido) throw new Error(validacao.mensagem);
          const novoElemento = { value: validacao.valor!, id: Date.now().toString() };
          setElementos([...elementos, novoElemento]);
          setIndiceDestacado(elementos.length);
          registrarOperacao(`Elemento ${validacao.valor} adicionado ao final`, OperationState.COMPLETED);
          resultado = novoElemento;
          break;
        }
        case 'estender': {
          const valores = valor.split(',').map(v => v.trim()).map(v => {
            const validacao = validacoes.validarNumero(v);
            if (!validacao.valido) throw new Error(validacao.mensagem);
            return validacao.valor!;
          });
          const novosElementos = [...elementos, ...valores.map(v => ({ value: v, id: Date.now().toString() }))];
          setElementos(novosElementos);
          registrarOperacao(`${valores.length} elementos adicionados`, OperationState.COMPLETED);
          resultado = null;
          break;
        }
        case 'removerDoFinal': {
          if (elementos.length === 0) throw new Error('Vetor vazio');
          const elementoRemovido = elementos.pop()!;
          setElementos([...elementos]);
          registrarOperacao(`Elemento ${elementoRemovido.value} removido do final`, OperationState.COMPLETED);
          resultado = elementoRemovido;
          break;
        }
        case 'fatiar': {
          const inicio = parseInt(indice);
          const fim = parseInt(indiceSecundario || '');
          if (isNaN(inicio) || isNaN(fim) || inicio < 0 || fim > elementos.length || inicio > fim) {
            throw new Error('Intervalo inválido');
          }
          const fatiado = elementos.slice(inicio, fim);
          registrarOperacao(`Fatiamento: ${fatiado.map(e => e.value)}`, OperationState.COMPLETED);
          resultado = fatiado;
          break;
        }
        case 'contem': {
          const validacao = validacoes.validarNumero(valor);
          if (!validacao.valido) throw new Error(validacao.mensagem);
          const contem = elementos.some(e => e.value === validacao.valor);
          registrarOperacao(`O vetor ${contem ? 'contém' : 'não contém'} o elemento ${validacao.valor}`, OperationState.COMPLETED);
          resultado = contem;
          break;
        }
        case 'indiceDe': {
          const validacao = validacoes.validarNumero(valor);
          if (!validacao.valido) throw new Error(validacao.mensagem);
          const indiceEncontrado = elementos.findIndex(e => e.value === validacao.valor);
          registrarOperacao(`Índice de ${validacao.valor}: ${indiceEncontrado}`, OperationState.COMPLETED);
          setIndiceDestacado(indiceEncontrado);
          resultado = indiceEncontrado;
          break;
        }
      }
      return resultado;
    } catch (error: any) {
      setMensagemAcao(`Erro: ${error.message}`);
      setOperationState(OperationState.ERROR);
      throw error;
    }
  }, [elementos, capacidadeInicial, registrarOperacao, validarIndice]);

  return {
    elementos,
    historico,
    mensagemAcao,
    indiceDestacado,
    executarMetodo,
    capacidadeMaxima: capacidadeInicial,
    registrarOperacao,
    setOperationState,
    setIndiceDestacado,
    setMensagemAcao
  };
}