// src/pages/index.ts
export { HomePage } from './HomePage';
export { StructurePage } from './StructurePage';